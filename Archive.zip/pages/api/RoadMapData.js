

export default function handler(req, res) {
    
    res.status(200).json({ 
        RM_Title: "Road Map",
        RM_Content: "If your actions create a legacy that inspires others to dream more, learn more, do more and become more, then, you are an excellent leader.",
        RM_Card1:{
            Title: "This is a tooltip",
            body:"Tooltips are used to describe or identify an element. In most scenarios, tooltips help the user understand the meaning, function or alt-text of an element."
        },
    
        RM_Card2:{
            Title: "This is a tooltip",
            body:"Tooltips are used to describe or identify an element. In most scenarios, tooltips help the user understand the meaning, function or alt-text of an element."
        },
    
        RM_Card3:{
            Title: "This is a tooltip",
            body:"Tooltips are used to describe or identify an element. In most scenarios, tooltips help the user understand the meaning, function or alt-text of an element."
        },
    
        RM_Card4:{
            Title: "This is a tooltip",
            body:"Tooltips are used to describe or identify an element. In most scenarios, tooltips help the user understand the meaning, function or alt-text of an element."
        },
    
        RM_Card5:{
            Title: "This is a tooltip",
            body:"Tooltips are used to describe or identify an element. In most scenarios, tooltips help the user understand the meaning, function or alt-text of an element."
        },
    
    })
  }
  