
export default function handler(req, res) {
    
    res.status(200).json({ 
        Hero_Title: "I’m woman phenomenally",
        Hero_Content: "The Awakened Woman is a thriving community focused on empowering women to live their most magnificent lives in all areas; Physically, Mentally, Spiritually & Financially",
        Hero_btn:"mint NFT"
        
    })
  }
  